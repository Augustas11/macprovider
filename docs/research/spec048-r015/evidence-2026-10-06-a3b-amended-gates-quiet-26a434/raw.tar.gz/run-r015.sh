#!/bin/bash
# Formal R015, amended gates, quiet window. The operator authorized pausing the
# live provider (live.malibu.provider, :8080) for this run only. The live
# provider is restored on every exit path (trap).
set -uo pipefail
export PATH=/usr/sbin:/usr/bin:/bin:/opt/homebrew/bin
ROOT=/Users/a1/mtp-r015-amended-26a434-20261006
SOURCE=$ROOT/src
BIN="$SOURCE/phase3-binary/.build/arm64-apple-macosx/release/macprovider-cli"
FIXTURE=/Users/a1/.cache/macprovider-mtp-e2e/q36-a3b-cat
POLICY="$ROOT/policy.json"
OUT="$ROOT/r015-a3b-amended-gates-quiet-26a434.jsonl"
POLICY_SHA=e24cb7bc4599cfb7281f3dc3985efd6c3b7c9a3b61e424bbc0435d8ea756d44a
PROVIDER_COMMIT=e1103712d408a0b158ac17dd8834875245874a42
MODEL_ID=qwen/qwen3.6-35b-a3b
LIVE_LABEL=live.malibu.provider
LIVE_DOMAIN=gui/$(id -u)
LIVE_PLIST=/Users/a1/Library/LaunchAgents/live.malibu.provider.plist
LIVE_BIN=/Users/a1/macprovider/macprovider-cli
LIVE_SHA=a6ea51d7ad19359a21fac63995194523264035fbca2ab32dceeede9d9da739bb
LIVECTL=/Users/a1/lab-cb-sampling/live-ctl.py
LOCK=/Users/a1/.lab-window.lock
W="$ROOT/window"
mkdir -p "$W"
ts() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "$1 at=$(ts)" >> "$W/status.txt"; }

test "$(shasum -a 256 "$POLICY" | awk '{print $1}')" = "$POLICY_SHA" || { log "phase=policy_check exit_code=90"; exit 90; }
test "$(cat "$SOURCE/SOURCE_COMMIT")" = "$PROVIDER_COMMIT" || { log "phase=commit_check exit_code=91"; exit 91; }
test ! -e "$OUT" || { log "phase=out_exists exit_code=92"; exit 92; }
test "$(shasum -a 256 "$LIVE_BIN" | awk '{print $1}')" = "$LIVE_SHA" || { log "phase=live_bin_check exit_code=93"; exit 93; }

# Lab lock: wait for it, never break someone else's.
until mkdir "$LOCK" 2>/dev/null; do sleep 30; done
echo "r015-amended-quiet $(ts) pid $$" > "$LOCK/owner"
log "lock_acquired"

SAMPLER_PID=""
LIVE_STOPPED=0
restore_live() {
  [ -n "$SAMPLER_PID" ] && kill "$SAMPLER_PID" 2>/dev/null
  if [ "$LIVE_STOPPED" = 1 ]; then
    log "live_restore_begin"
    launchctl print "$LIVE_DOMAIN/$LIVE_LABEL" >/dev/null 2>&1 || launchctl bootstrap "$LIVE_DOMAIN" "$LIVE_PLIST"
    ok=0
    for i in $(seq 1 60); do
      if "$LIVE_BIN" status 2>&1 | grep -q "Provider is ready"; then ok=1; break; fi
      sleep 10
    done
    if [ $ok = 1 ]; then log "live_restored_ready"; else
      log "live_not_ready_after_bootstrap; kickstart"
      launchctl kickstart -k "$LIVE_DOMAIN/$LIVE_LABEL"
      for i in $(seq 1 60); do "$LIVE_BIN" status 2>&1 | grep -q "Provider is ready" && { ok=1; break; }; sleep 10; done
      [ $ok = 1 ] && log "live_restored_ready_after_kickstart" || log "live_STILL_DOWN"
    fi
    "$LIVE_BIN" status --advanced > "$W/live-status-after.txt" 2>&1
    ps -axo pid,lstart,command | grep "$LIVE_BIN serve" | grep -v grep > "$W/live-process-after.txt"
    LIVE_STOPPED=0
  fi
  rm -rf "$LOCK"
  log "lock_released"
}
trap restore_live EXIT
trap 'exit 130' INT TERM

"$LIVE_BIN" status --advanced > "$W/live-status-before.txt" 2>&1
log "live_pause_start"
/usr/bin/python3 "$LIVECTL" pause > "$W/live-pause-ack.txt" 2>&1 || log "live_pause_request_failed rc=$?"
LIVE_STOPPED=1
launchctl bootout "$LIVE_DOMAIN/$LIVE_LABEL" >> "$W/live-pause-ack.txt" 2>&1
for i in $(seq 1 30); do pgrep -f "^$LIVE_BIN serve" >/dev/null || break; sleep 2; done
if pgrep -f "^$LIVE_BIN serve" >/dev/null; then log "phase=live_stop exit_code=94"; exit 94; fi
log "live_stopped"

# GPU quiet check (20 s). The Trusted Pool M1 member (:18120/:18130) is not
# stopped and not counted as blocking; its load is recorded below.
for i in $(seq 1 20); do ioreg -r -c IOAccelerator -d 1 2>/dev/null | grep -o '"Device Utilization %"=[0-9]*' | head -1; sleep 1; done > "$W/gpu-preflight.txt"
ps -axo pid,%cpu,etime,command | sort -k2 -nr | head -15 > "$W/procs-preflight.txt"
log "gpu_preflight median=$(sed 's/.*=//' "$W/gpu-preflight.txt" | sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}')"

(
  while true; do
    echo "$(ts) out_lines=$( [ -e "$OUT" ] && wc -l < "$OUT" | tr -d ' ' || echo 0) gpu=$(ioreg -r -c IOAccelerator -d 1 2>/dev/null | grep -o '"Device Utilization %"=[0-9]*' | head -1 | sed 's/.*=//') pool=$(for p in $(lsof -nP -t -iTCP:18120 -iTCP:18130 -sTCP:LISTEN 2>/dev/null) ; do ps -o %cpu= -p $p; done | awk '{s+=$1} END{printf "%.1f", s}') other=$(ps -axo %cpu,command | grep -E 'macprovider-cli|llama-server|mlx|python' | grep -v -E "$ROOT|grep" | awk '{s+=$1} END{printf "%.1f", s}')"
    sleep 10
  done
) > "$W/contamination.log" 2>&1 &
SAMPLER_PID=$!

{
  echo "started_at=$(ts)"
  echo "host=$(hostname) os_build=$(sysctl -n kern.osversion) hw_model=$(sysctl -n hw.model)"
  echo "policy_sha256=$POLICY_SHA"
  echo "provider_commit=$PROVIDER_COMMIT"
  echo "binary_sha256=$(shasum -a 256 "$BIN" | awk '{print $1}')"
  echo "metallib_sha256=$(shasum -a 256 "$(dirname "$BIN")/mlx.metallib" | awk '{print $1}')"
} > "$W/identity.txt"

MACPROVIDER_NATIVE_MTP_E2E=1 MACPROVIDER_NATIVE_MTP_E2E_SERVE_PATH=1 \
  "$BIN" native-mtp-hardware-e2e --root "$FIXTURE" --model-id "$MODEL_ID" \
  --max-batch 2 --sizing-prompt-tokens 1024 --sizing-output-tokens 256 \
  > "$W/hardware-e2e.log" 2>&1
rc=$?; log "phase=hardware_e2e exit_code=$rc"; [ $rc -eq 0 ] || exit $rc

log "matrix_started"
MACPROVIDER_NATIVE_MTP_E2E=1 "$BIN" native-mtp-bench --root "$FIXTURE" --model-id "$MODEL_ID" \
  --policy "$POLICY" --out "$OUT" --phase matrix --provider-commit "$PROVIDER_COMMIT" \
  > "$W/bench-matrix.log" 2>&1
rc=$?; log "phase=matrix exit_code=$rc jsonl_sha256=$(shasum -a 256 "$OUT" | awk '{print $1}') lines=$(wc -l < "$OUT" | tr -d ' ')"; [ $rc -eq 0 ] || exit $rc
cp "$OUT" "$ROOT/r015-matrix-only.jsonl"

log "sustained_started"
MACPROVIDER_NATIVE_MTP_E2E=1 "$BIN" native-mtp-bench --root "$FIXTURE" --model-id "$MODEL_ID" \
  --policy "$POLICY" --out "$OUT" --phase sustained --provider-commit "$PROVIDER_COMMIT" \
  > "$W/bench-sustained.log" 2>&1
rc=$?; log "phase=sustained exit_code=$rc jsonl_sha256=$(shasum -a 256 "$OUT" | awk '{print $1}') lines=$(wc -l < "$OUT" | tr -d ' ')"; [ $rc -eq 0 ] || exit $rc
log "phase=all exit_code=0"
