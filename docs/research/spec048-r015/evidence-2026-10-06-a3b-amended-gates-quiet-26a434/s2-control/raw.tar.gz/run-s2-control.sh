#!/bin/bash
# Exploratory s2 attribution control (not a gate): 10-06 binary vs step-overhead binary, old/new/new/old, one lab lock.
set -uo pipefail
C=/Users/a1/mtp-r015-amended-26a434-20261006/s2-control
FIX=/Users/a1/.cache/macprovider-mtp-e2e/q36-a3b-cat
OLD=/Users/a1/mtp-r015-26a434-20261006/src/phase3-binary/.build/arm64-apple-macosx/release/macprovider-cli
NEW=/Users/a1/mtp-r015-step-overhead-26a434-20261006/src/phase3-binary/.build/arm64-apple-macosx/release/macprovider-cli
LOCK=/Users/a1/.lab-window.lock
until mkdir "$LOCK" 2>/dev/null; do sleep 30; done
echo "s2-control $(date -u +%FT%TZ) pid $$" > "$LOCK/owner"
(
  while true; do date -u +%FT%TZ; for i in 1 2 3 4 5; do ioreg -r -c IOAccelerator -d 1 2>/dev/null | grep -o "\"Device Utilization %\"=[0-9]*" | head -1; sleep 1; done | tr "\n" " "; echo; sleep 20; done
) > $C/gpu.log 2>&1 &
SP=$!; trap "kill $SP 2>/dev/null || true; rm -rf $LOCK" EXIT
echo "lock_acquired $(date -u +%FT%TZ)" >> $C/status.txt
for run in old1 new1 new2 old2; do
  case $run in old*) BIN=$OLD; PC=280f0e95d623353873147e523391e78d71327c5b; P=$C/s2-old-policy.json;; new*) BIN=$NEW; PC=006a34ba845f3a5b2d306eb77356f0d5f6e59a07; P=$C/s2-new-policy.json;; esac
  echo "$(date -u +%FT%TZ) start $run" >> $C/status.txt
  MACPROVIDER_NATIVE_MTP_E2E=1 "$BIN" native-mtp-bench --root $FIX --model-id qwen/qwen3.6-35b-a3b --policy $P --out $C/$run.jsonl --phase matrix --provider-commit $PC > $C/$run.log 2>&1; rc=$?
  echo "$(date -u +%FT%TZ) end $run exit=$rc" >> $C/status.txt
done
echo DONE >> $C/status.txt
