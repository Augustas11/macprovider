#!/bin/bash
set -uo pipefail
ROOT=/Users/a1/mtp-r015-step-overhead-26a434-20261006
SOURCE=$ROOT/src
BIN="$SOURCE/phase3-binary/.build/arm64-apple-macosx/release/macprovider-cli"
FIXTURE=/Users/a1/.cache/macprovider-mtp-e2e/q36-a3b-cat
POLICY="$ROOT/policy.json"
OUT="$ROOT/r015-a3b-step-overhead-26a434.jsonl"
POLICY_SHA=0c1b42bec091ab762ba56c9c8d460b9cf2ddc74950f9d98aa59d0af7b290aa87
PROVIDER_COMMIT=006a34ba845f3a5b2d306eb77356f0d5f6e59a07
MODEL_ID=qwen/qwen3.6-35b-a3b
W="$ROOT/window"
mkdir -p "$W"
fail() { echo "phase=$1 exit_code=$2 finished_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$W/status.txt"; exit "$2"; }
test "$(shasum -a 256 "$POLICY" | awk '{print $1}')" = "$POLICY_SHA" || fail policy_check 90
test "$(cat "$SOURCE/SOURCE_COMMIT")" = "$PROVIDER_COMMIT" || fail commit_check 91
test ! -e "$OUT" || fail out_exists 92
{
  echo "started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "host=$(hostname) os_build=$(sysctl -n kern.osversion) hw_model=$(sysctl -n hw.model)"
  echo "policy_sha256=$POLICY_SHA"
  echo "provider_commit=$PROVIDER_COMMIT"
  echo "binary_sha256=$(shasum -a 256 "$BIN" | awk '{print $1}')"
  echo "metallib_sha256=$(shasum -a 256 "$(dirname "$BIN")/mlx.metallib" | awk '{print $1}')"
} > "$W/identity.txt"
(
  while true; do
    date -u +%Y-%m-%dT%H:%M:%SZ
    ps -axo pid,ppid,etime,%cpu,comm | grep -E 'macprovider-cli|llama|ollama|python|mlx' | grep -v grep || true
    vm_stat | head -n 2
    for i in 1 2 3 4 5; do ioreg -r -c IOAccelerator -d 1 2>/dev/null | grep -o "\"Device Utilization %\"=[0-9]*" | head -1; sleep 1; done | tr "\n" " "; echo
    sleep 60
  done
) > "$W/contamination.log" 2>&1 &
SAMPLER_PID=$!
trap 'kill "$SAMPLER_PID" 2>/dev/null || true' EXIT INT TERM

MACPROVIDER_NATIVE_MTP_E2E=1 MACPROVIDER_NATIVE_MTP_E2E_SERVE_PATH=1 \
  "$BIN" native-mtp-hardware-e2e --root "$FIXTURE" --model-id "$MODEL_ID" \
  --max-batch 2 --sizing-prompt-tokens 1024 --sizing-output-tokens 256 \
  > "$W/hardware-e2e.log" 2>&1
rc=$?; echo "phase=hardware_e2e exit_code=$rc at=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$W/status.txt"; [ $rc -eq 0 ] || fail hardware_e2e $rc

echo "matrix_started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$W/status.txt"
MACPROVIDER_NATIVE_MTP_E2E=1 "$BIN" native-mtp-bench --root "$FIXTURE" --model-id "$MODEL_ID" \
  --policy "$POLICY" --out "$OUT" --phase matrix --provider-commit "$PROVIDER_COMMIT" \
  > "$W/bench-matrix.log" 2>&1
rc=$?; echo "phase=matrix exit_code=$rc at=$(date -u +%Y-%m-%dT%H:%M:%SZ) jsonl_sha256=$(shasum -a 256 "$OUT" | awk '{print $1}') lines=$(wc -l < "$OUT" | tr -d ' ')" >> "$W/status.txt"; [ $rc -eq 0 ] || fail matrix $rc
cp "$OUT" "$ROOT/r015-matrix-only.jsonl"

echo "sustained_started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$W/status.txt"
MACPROVIDER_NATIVE_MTP_E2E=1 "$BIN" native-mtp-bench --root "$FIXTURE" --model-id "$MODEL_ID" \
  --policy "$POLICY" --out "$OUT" --phase sustained --provider-commit "$PROVIDER_COMMIT" \
  > "$W/bench-sustained.log" 2>&1
rc=$?; echo "phase=sustained exit_code=$rc at=$(date -u +%Y-%m-%dT%H:%M:%SZ) jsonl_sha256=$(shasum -a 256 "$OUT" | awk '{print $1}') lines=$(wc -l < "$OUT" | tr -d ' ')" >> "$W/status.txt"; [ $rc -eq 0 ] || fail sustained $rc
echo "phase=all exit_code=0 finished_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$W/status.txt"
